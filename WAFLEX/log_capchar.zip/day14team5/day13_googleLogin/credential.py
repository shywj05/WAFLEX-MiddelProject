'''
Created on 25 Mar 2021

@author: shane
'''
CLIENT_ID = '844016043086-at1ghdr09757hpf7gag5j120hlch1n02.apps.googleusercontent.com'
CLIENT_SECRET = 'TTbqYKg_ljv8aZXQJ9WhqnsM'